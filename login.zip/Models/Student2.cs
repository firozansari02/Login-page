﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Login_page_project.Models
{
    public partial class Student2
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = null!;

        [Required]
        public string? Gender { get; set; }

        [Required]
        public int? Age { get; set; }
        [Required]
        public string? Email { get; set; }

        [DataType(DataType.Password)]
        [Required]
        public int? Password { get; set; }
    }
}
